from django import forms
from .models import Pass
from .models import Ticket
from .models import BusPass
from .models import Complain
class PassForm(forms.ModelForm):
    class Meta:
        model = Pass
        fields = ['student', 'pass_type', 'issue_date', 'expiration_date']

class FareCalculationForm(forms.Form):
    Source = forms.CharField(max_length=100, label='Source')
    Destination = forms.CharField(max_length=100, label='Destination')


class DepotForm(forms.Form):
    depot_name = forms.CharField(label='Enter Bus Depot Name', max_length=255)




class TicketForm(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ['type_of_bus', 'phone_number', 'source', 'destination', 'seat_number', 'number_of_tickets', 'date', 'time']




class BusPassForm(forms.ModelForm):
    class Meta:
        model = BusPass
        fields = ['first_name', 'last_name', 'start_date', 'end_date', 'college', 'months', 'source', 'destination']


# forms.py


class ComplainForm(forms.ModelForm):
    class Meta:
        model = Complain
        fields = ['firstname', 'lastname', 'location', 'phone', 'happening', 'name_of_victim']
