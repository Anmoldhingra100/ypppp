from django.db import models

# Create your models here.

class Route(models.Model):
    source = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    fare = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.source} to {self.destination} - ₹{self.fare:.2f}"



class BusDepot(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class Bus(models.Model):
    depot = models.ForeignKey(BusDepot, on_delete=models.CASCADE)
    bus_number = models.CharField(max_length=50)
    timing = models.TimeField()

    def __str__(self):
        return f"Bus {self.bus_number} at {self.timing}"





class Student(models.Model):
    name = models.CharField(max_length=100)
    student_id = models.CharField(max_length=20, unique=True)

    def __str__(self):
        return self.name

class Pass(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    pass_type = models.CharField(max_length=50)
    issue_date = models.DateField()
    expiration_date = models.DateField()

    def __str__(self):
        return f'{self.pass_type} for {self.student.name}'


class Ticket(models.Model):
    type_of_bus = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15)
    source = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    seat_number = models.CharField(max_length=100)
    number_of_tickets = models.IntegerField()
    date = models.DateField()
    time = models.TimeField()

    def __str__(self):
        return f"{self.type_of_bus} - {self.source} to {self.destination}"



class BusPass(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    start_date = models.DateField()
    end_date = models.DateField()
    college = models.CharField(max_length=100)
    months = models.IntegerField()
    source = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.start_date} to {self.end_date}"



# models.py



class Complain(models.Model):
    firstname = models.CharField(max_length=100)
    lastname = models.CharField(max_length=100)
    location = models.CharField(max_length=255)
    phone = models.CharField(max_length=15)
    happening = models.TextField()
    name_of_victim = models.CharField(max_length=100)

    def __str__(self):
        return f'{self.firstname} {self.lastname}'
