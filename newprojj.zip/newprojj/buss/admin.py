from django.contrib import admin
from .models import Ticket  # Make sure to import your Ticket model
from .models import Complain 
# Define a ModelAdmin class to customize the admin interface
class TicketAdmin(admin.ModelAdmin):
    list_display = ('type_of_bus', 'phone_number', 'source', 'destination', 'seat_number', 'number_of_tickets', 'date', 'time')
    search_fields = ('type_of_bus', 'source', 'destination')  # Fields you can search by
    list_filter = ('date',)  # Add filtering options in the admin

# Register the Ticket model with the admin site
admin.site.register(Ticket, TicketAdmin)



 # Import the Complain model

@admin.register(Complain)
class ComplainAdmin(admin.ModelAdmin):
    list_display = ('firstname', 'lastname', 'location', 'phone', 'name_of_victim')  # Customize the displayed fields
    search_fields = ('firstname', 'lastname', 'location', 'phone', 'name_of_victim')  # Add search capability
